import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from collect import classify, allowed_url, collect_source, extract_pubdate, looks_like_article, normalize_date
from datetime import datetime,timezone

class Tests(unittest.TestCase):
 def setUp(self):
  self.s={'id':'br-a-palmeiras','name':'Palmeiras','domain':'palmeiras.com.br','url':'https://www.palmeiras.com.br/noticias/'}
 def test_labels(self):
  self.assertEqual(classify('Flaco López renova contrato até 2030'),'renovacao')
  self.assertEqual(classify('Boletim médico: jogador passa por cirurgia'),'lesao')
  self.assertEqual(classify('Seleção Brasileira divulga convocação'),'convocacao')
  self.assertEqual(classify('Comunicado oficial'),'comunicado')
 def test_reject_speculation_and_out_of_scope(self):
  self.assertIsNone(classify('Clube negocia com atacante e pode contratar em janeiro'))
  self.assertIsNone(classify('Women injury update for Arsenal academy'))
  self.assertIsNone(classify('Sub-20: atacante assina contrato'))
 def test_domain_exact_or_subdomain(self):
  self.assertTrue(allowed_url('https://www.palmeiras.com.br/noticias/atacante-renova','palmeiras.com.br'))
  self.assertFalse(allowed_url('https://palmeiras.com.br.bad.com/noticias/foo','palmeiras.com.br'))
  self.assertFalse(allowed_url('http://palmeiras.com.br/noticias/foo','palmeiras.com.br'))
  self.assertFalse(allowed_url('https://example.com/noticias/foo','palmeiras.com.br'))
 def test_meta_date(self):
  b=b'<html><meta property="article:published_time" content="2026-11-16T11:00:00-03:00"></html>'
  self.assertEqual(extract_pubdate(b).isoformat(),'2026-11-16T14:00:00+00:00')
 def test_fixture_end_to_end_no_outside_links(self):
  index=b'''<html><a href="/noticias/atacante-renova-2026">Atacante renova contrato por mais duas temporadas</a>
  <a href="/noticias/injuried-women">Women injury update in Arsenal academy</a>
  <a href="https://random-blog.example/noticias/fake">Goleiro lesionado</a>
  <a href="/noticias/contratacao-rumor">Clube pode contratar reforco em janeiro</a></html>'''
  page=b'<html><script type="application/ld+json">{"datePublished":"2026-11-16T14:00:00Z"}</script></html>'
  def fetch(url,domain):return (index if '/atacante-' not in url else page,url,'text/html')
  rows=collect_source(self.s,fetch=fetch,now=datetime(2026,11,16,16,tzinfo=timezone.utc))
  self.assertTrue(rows['ok']);self.assertEqual(len(rows['articles']),1)
  a=rows['articles'][0]
  self.assertEqual(a['category'],'renovacao');self.assertEqual(a['published_at'],'2026-11-16T14:00:00+00:00')
 def test_old_article_rejected(self):
  index=b'<a href="/noticias/renovacao-de-jogador">Jogador renova contrato ate 2029</a>'
  page=b'<script type="application/ld+json">{"datePublished":"2025-06-16T14:00:00Z"}</script>'
  def fetch(url,dom):return (index if url.endswith('/noticias/') else page,url,'text/html')
  rows=collect_source(self.s,fetch=fetch,now=datetime(2026,11,16,16,tzinfo=timezone.utc))
  self.assertEqual(rows['articles'],[])

if __name__=='__main__':unittest.main()
