import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const store={};
const rows={
 radar_articles:[{id:'a',entity_id:'br-a-palmeiras',title:'Teste de contrato',category:'renovacao',first_seen:'2026-11-16T13:00:00Z',published_at:null,source:'Site oficial',url:'https://palmeiras.com.br/noticias/teste',priority:4}],
 radar_sources:[{id:'br-a-palmeiras',checked_at:new Date().toISOString(),ok:true}],
 radar_settings:[],radar_marks:[]
};
const fetchCalls=[];
async function mockFetch(url,options){
 fetchCalls.push([url,options]);const path=new URL(url).pathname;
 let data=null,status=200;
 if(path==='/auth/v1/token')data={access_token:'jwt-test',refresh_token:'refresh-test',expires_in:3600,user:{id:'00000000-0000-0000-0000-000000000001'}};
 else if(path==='/auth/v1/user')data={id:'00000000-0000-0000-0000-000000000001'};
 else if(path.startsWith('/rest/v1/')){
  const table=path.replace('/rest/v1/','');
  if(options.method==='POST'){data=null;status=204;}else data=rows[table]||[];
 } else {status=404;data={error:'unknown'}};
 return {ok:status<300,status,async json(){return data}};
}
const context={window:{RADAR_CONFIG:{supabaseUrl:'https://abc123.supabase.co',supabasePublishableKey:'sb_publishable_test_public_key_a_long_value',pilotIds:['br-a-palmeiras']},RADAR_CATALOG:{entities:[{id:'br-a-palmeiras',name:'Palmeiras'}]}},fetch:mockFetch,sessionStorage:{getItem(k){return store[k]??null},setItem(k,v){store[k]=v},removeItem(k){delete store[k]}},Date,Error,URL,JSON,Promise,Set,Object,console,encodeURIComponent};
vm.runInNewContext(fs.readFileSync(new URL('../docs/cloud-api.js',import.meta.url),'utf8'),context);
assert.equal(context.window.radarCloud.configured,true);
await context.window.radarCloud.dispatch('/api/login',{email:'a@example.com',password:'dummy'});
const snap=await context.window.radarCloud.dispatch('/api/snapshot');
assert.equal(snap.articles.length,1);assert.equal(snap.sources[0].state,'online');assert.equal(snap.settings.selected[0],'br-a-palmeiras');
await context.window.radarCloud.dispatch('/api/mark',{id:'a',action:'save',value:true});
assert.equal(fetchCalls.some(([u,opt])=>u.includes('/rest/v1/radar_marks')&&opt.method==='POST'),true);
await context.window.radarCloud.dispatch('/api/logout',{});
assert.equal(store['radar-v6-session'],undefined);
console.log('Cloud adapter: login, snapshot, save e logout OK (API simulada)');
